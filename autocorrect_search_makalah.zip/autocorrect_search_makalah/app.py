from flask import Flask, render_template, request, jsonify
import mysql.connector
from mysql.connector import Error
import math
from collections import Counter

app = Flask(__name__)

# Fungsi untuk membuat koneksi ke database MySQL
def connect_to_db():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="jurnal"
        )
        return connection
    except Error as e:
        print(f"Error: {e}")
        return None


# Fungsi untuk Algoritma LD
def levenshtein_distance(S, T):
    n, m = len(S), len(T)
    if n > m:
        S, T = T, S
        n, m = m, n

    current_row = range(n + 1)
    for i in range(1, m + 1):
        previous_row, current_row = current_row, [i] + [0] * n
        for j in range(1, n + 1):
            penambahan = previous_row[j] + 1
            penghapusan = current_row[j - 1] + 1
            pengubahan = previous_row[j - 1] + (S[j - 1] != T[i - 1])
            current_row[j] = min(penambahan, penghapusan, pengubahan)

    return current_row[n]


# Fungsi untuk mencari jarak LD terkecil
def levenshtein_correction(word):
    conn = connect_to_db()
    cursor = conn.cursor()
    cursor.execute("SELECT kata FROM kamus WHERE kata = %s", (word,))
    closest_word = cursor.fetchone()
    if closest_word :
        closest_word = word
    else :
        cursor.execute("SELECT kata FROM kamus")
        words = cursor.fetchall()
        conn.close()
        closest_word = word
        min_distance = float('inf')
        for w in words:
            w = w[0]
            distance = levenshtein_distance(word, w)
            if distance <= 1:
                closest_word = w

    return closest_word


# Fungsi untuk menyimpan kata dan status auto-correct ke database
def save_word_to_db(word, corrected_word, is_corrected):
    conn = connect_to_db()
    cursor = conn.cursor()
    query = "INSERT INTO autocorrect_log (word, corrected_word, is_corrected) VALUES (%s, %s, %s)"
    cursor.execute(query, (word, corrected_word, is_corrected))
    conn.commit()
    cursor.close()
    conn.close()


# Fungsi untuk menghitung TP, TN, FP, FN dan menyimpannya di database
def evaluate_autocorrect():
    conn = connect_to_db()
    cursor = conn.cursor()
    cursor.execute("SELECT word, corrected_word, is_corrected FROM autocorrect_log")
    logs = cursor.fetchall()

    tp = tn = fp = fn = 0

    for log in logs:
        word, corrected_word, is_corrected = log
        if word == corrected_word and is_corrected == 0:
            tn += 1
        elif word == corrected_word and is_corrected == 1:
            fn += 1
        elif word != corrected_word and is_corrected == 1:
            tp += 1
        elif word != corrected_word and is_corrected == 0:
            fp += 1

    query = "REPLACE INTO evaluation (id, tp, tn, fp, fn) VALUES (1, %s, %s, %s, %s)"
    cursor.execute(query, (tp, tn, fp, fn))
    conn.commit()
    cursor.close()
    conn.close()


# Fungsi untuk mengambil data jurnal dari tabel data_jurnal
# Fungsi untuk menghitung TF
def compute_tf(word_dict, doc):
    tf_dict = {}
    doc_count = len(doc)
    for word, count in word_dict.items():
        tf_dict[word] = count / float(doc_count)
    return tf_dict


# Fungsi untuk menghitung IDF
def compute_idf(doc_list):
    idf_dict = {}
    N = len(doc_list)

    # Mengumpulkan semua kata dari semua dokumen
    all_words = set()
    for doc in doc_list:
        all_words.update(doc.keys())

    # Inisialisasi idf_dict dengan semua kata
    idf_dict = dict.fromkeys(all_words, 0)

    for doc in doc_list:
        for word in doc.keys():
            if doc[word] > 0:
                idf_dict[word] += 1

    for word, val in idf_dict.items():
        idf_dict[word] = math.log(N / float(val))

    return idf_dict


# Fungsi untuk menghitung TF-IDF
def compute_tfidf(tf, idf):
    tfidf = {}
    for word, val in tf.items():
        tfidf[word] = val * idf[word]
    return tfidf


# Fungsi untuk memproses teks menjadi token
def tokenize(text):
    words = text.lower().split()
    return Counter(words)


# Mengambil data dari database
def fetch_data():
    db = connect_to_db()
    cursor = db.cursor()
    cursor.execute("SELECT id_dj, judul, abstrak, author, link_pdf FROM data_jurnal")
    rows = cursor.fetchall()
    cursor.close()
    db.close()
    return rows


rows = fetch_data()

# Mempersiapkan dokumen dan token
documents = []
for row in rows:
    text = f"{row[1]} {row[2]} {row[3]}"
    documents.append(tokenize(text))

# Menghitung TF untuk setiap dokumen
tf_list = []
for doc in documents:
    tf_list.append(compute_tf(doc, doc))

# Menghitung IDF
idf = compute_idf(documents)

# Menghitung TF-IDF untuk setiap dokumen
tfidf_list = []
for tf in tf_list:
    tfidf_list.append(compute_tfidf(tf, idf))


# Fungsi untuk menghitung skor kesamaan (dot product) antara query dan dokumen
def cosine_similarity(tfidf_query, tfidf_doc):
    dot_product = sum(tfidf_query[word] * tfidf_doc.get(word, 0) for word in tfidf_query)
    query_norm = sum(val ** 2 for val in tfidf_query.values()) ** 0.5
    doc_norm = sum(val ** 2 for val in tfidf_doc.values()) ** 0.5
    if query_norm * doc_norm == 0:
        return 0.0
    else:
        return dot_product / (query_norm * doc_norm)


@app.route('/')
def index():
    return render_template('index.html')


# Route untuk autocorrect tiap kata inputan
@app.route('/correct', methods=['POST'])
def correct():
    text = request.json.get('text')
    words = text.split()
    corrected_words = []
    for word in words:
        corrected_word = levenshtein_correction(word)
        is_corrected = 1 if word != corrected_word else 0
        save_word_to_db(word, corrected_word, is_corrected)
        corrected_words.append(corrected_word)
    corrected_text = ' '.join(corrected_words)
    evaluate_autocorrect()
    return jsonify(corrected_text=corrected_text)


# Fungsi pencarian
@app.route('/search', methods=['POST'])
def search():
    query = request.form['query']
    query_tokens = tokenize(query)
    tf_query = compute_tf(query_tokens, query_tokens)
    tfidf_query = compute_tfidf(tf_query, idf)

    results = []
    for i, tfidf_doc in enumerate(tfidf_list):
        score = cosine_similarity(tfidf_query, tfidf_doc)
        if score > 0:
            results.append((score, rows[i]))

    results.sort(reverse=True, key=lambda x: x[1])
    return render_template('index.html', results=results)


# Route untuk melihat evaluasi
@app.route('/CM')
def evaluation():
    conn = connect_to_db()
    cursor = conn.cursor()
    cursor.execute("SELECT tp, tn, fp, fn FROM evaluation WHERE id = 1")
    evaluation_data = cursor.fetchone()
    cursor.close()
    conn.close()

    if evaluation_data:
        tp, tn, fp, fn = evaluation_data
        accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
        return render_template('CM.html', tp=tp, tn=tn, fp=fp, fn=fn, accuracy=accuracy)
    else:
        return render_template('CM.html', tp=0, tn=0, fp=0, fn=0, accuracy=0)


if __name__ == "__main__":
    app.run(debug=True)
