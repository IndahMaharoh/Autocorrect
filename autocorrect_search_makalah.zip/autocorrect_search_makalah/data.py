import pandas as pd
import mysql.connector

# Ganti 'your_excel_file.xlsx' dengan nama file Excel Anda
df = pd.read_excel('C:/xampp/htdocs/autocorrect_search_makalah/data.xlsx')

# Ganti parameter berikut sesuai dengan konfigurasi database Anda
user = 'root'
password = ''
host = 'localhost'
database = 'jurnal'

# Membuat koneksi ke database MySQL
conn = mysql.connector.connect(
    user=user,
    password=password,
    host=host,
    database=database
)

cursor = conn.cursor()

# Membuat tabel jika belum ada
cursor.execute("""
CREATE TABLE IF NOT EXISTS data_jurnal (
    id_dj INT AUTO_INCREMENT PRIMARY KEY,
    volume VARCHAR(255),
    judul TEXT,
    abstrak TEXT,
    author VARCHAR(255),
    link_pdf TEXT
)
""")

# Menyimpan DataFrame ke tabel 'data_jurnal' di database MySQL
for i, row in df.iterrows():
    sql = "INSERT INTO data_jurnal (volume, judul, abstrak, author, link_pdf) VALUES (%s, %s, %s, %s, %s)"
    cursor.execute(sql, (row['Volume'], row['Judul'], row['Abstrak'], row['Author'], row['Link_pdf']))

conn.commit()
cursor.close()
conn.close()

print("Data berhasil disimpan ke database MySQL")
