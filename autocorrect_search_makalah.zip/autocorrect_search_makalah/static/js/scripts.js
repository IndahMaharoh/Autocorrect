$(document).ready(function() {
    $('#input_text').on('input', function() {
        let text = $(this).val();
        let lastChar = text.slice(-1);
        
        if (lastChar === ' ') {
            let words = text.split(' ');
            let lastWord = words[words.length - 2];
            
            $.post('/autocorrect', { word: lastWord }, function(data) {
                words[words.length - 2] = data.corrected_word;
                $('#input_text').val(words.join(' ') + ' ');
            });
        }
    });
});
